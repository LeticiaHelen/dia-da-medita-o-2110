<?php
header('location: app/views/home.php');
?>