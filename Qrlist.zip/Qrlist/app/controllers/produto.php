<?php
session_start();
require __DIR__ . "/../conexao/Connection.php";
require __DIR__ . "/../models/Produto.php";
//require __DIR__."/../../imagens/";

function cabecalho(){
    require __DIR__ . "/../views/cabecalho.php";
}

function index(){
    require __DIR__ . "/../views/home.php";
}

function pagina_mercado(){
    require __DIR__.'/../views/mercado_paginaLog.php';
}

if (isset($_GET['acao']) and function_exists($_GET['acao'])) {
    call_user_func($_GET['acao']);
}


function produto_cadastro(){

    if (isset($_POST['cadastrar_produto'])) {
//        $conexaoCadastroProduto = getConexao();


        $desc_prod = $_POST['desc_prod'];
        $peso_liq = $_POST['peso_liq'];
        $nome_produto = filter_input(INPUT_POST, 'nome_produto', FILTER_SANITIZE_SPECIAL_CHARS);
        $preco_prod_un = $_POST['preco_prod'];
        $qtd_item_est = $_POST['qtd_item_est'];
        $cod_cat_cod = $_POST['cod_cat'];
        $marca = $_POST['marca'];
        $produto = new Produto();
        $foto_produto=$produto->valida_imagem($_FILES['foto_produto']);
        if ($foto_produto == 1){
            $t = explode('.', $_FILES['foto_produto']['name']);
            $nome_foto_produto = time().'.'.$t[1];
            $p = explode(',', $preco_prod_un);
            $preco_prod = $p[0].''.$p[1];
            move_uploaded_file($_FILES['foto_produto']['tmp_name'], '../../imagens/foto_produto/'.$nome_foto_produto.'');
            $produto->salvar_produto($desc_prod, $peso_liq, $nome_produto, $preco_prod, $qtd_item_est, $cod_cat_cod, $marca,$nome_foto_produto);
            pagina_mercado();
        }else{
            header("location: produto_cadastro.php?u=".$foto_produto."");
        }

        }else{
        header("location: produto_cadastro.php");
    }
}

// fazer delete, editar, listar

