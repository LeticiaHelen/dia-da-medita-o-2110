<html>
<head>
	<!-- Standard Meta -->
	<meta charset="utf-8">

	<!-- Site Properties -->
	<title>QrList</title>
	<link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<body>

	<?php include "cabecalho_geral.php" ?>

	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

			<div class="margin criarNovaLista">
				<center><h1>Criando Nova Lista</h1>
					<p>Dê um nome a sua lista</p>
					<div class="ui input">
						<input type="text" placeholder="Nome da lista">
					</div>
					<p></p>
					<p>Selecione todos os produtos que você deseja adicionar a lista, depois salve-a clicando em "Finalizar".</p></center>
				</div>

				<div class=" margin">
					<div class="ui horizontal divider"> 
						adicione produtos a sua lista
					</div>
				</div>

				<div class="filtro">
					<div class="ui search centro">
						<div class="ui icon input">
							<input class="prompt" type="text" placeholder="Pesquisar">
							<i class="search icon"></i>
						</div>

						<div class="ui floating labeled icon dropdown button drop direita">
							<i class="filter icon"></i>
							<span class="text">Filter</span>
							<div class="menu">
								<div class="header">
									<i class="tags icon"></i>
									Filtro
								</div>
								<div class="item">Todos os mercados</div>
								<div class="item">Mercado 1</div>
								<div class="item">Mercado 2</div>
							</div>
						</div>
					</div>			
				</div>

				<div class="conteudoNovaLista">
					
					<div class="cardProduto">
						<div class="ui card">
							<div class="content">
								<div class="header">Margarina</div>
							</div>
							<div class="content">
								<h4 class="ui sub header">categoria: frios</h4>
								<br>
								<img class="img_mercado" src="../../imagens/index.jpg">
								<p></p>
								<p class="ui sub header right floated">R$5,50</p>
								<p class="ui sub header">peso: 500g</p>
								<p class="ui sub header">Marca: Qualy</p>
								<p class="ui sub header">Mercado: Albino</p>
								<p class="ui sub header">descrição: Com lactose e gluten</p>
							</div>
							<div class="extra content">
								<button class="ui button">Adicionar</button>
							</div>
						</div>
					</div>

				</div>
				<div class="one wide column "></div>
			</div>

		</body>
<?php include "footer.php"  ?>