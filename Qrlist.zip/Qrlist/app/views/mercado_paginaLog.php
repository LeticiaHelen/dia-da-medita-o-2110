<?php
session_start();
if (isset($_SESSION['logado']) and $_SESSION['logado'] = "sim") {
if (isset($_SESSION['mercado']['logado']) and $_SESSION['mercado']['logado'] = "sim") {
require __DIR__.'/cabecalho_geral.php';
?>

<body>

	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

        <div class="ui middle aligned divided list marginUsu">
        <div class="item">
          <div class="right floated content">
            <div class="ui button">Editar</div>
          </div>
          <div class="header"><h3>Nome Mercado</h3></div>
          <div class="ui horizontal bulleted list">
            <div class="item">email@mercado.com</div>
            <div class="item">77.854.934/6452-87</div>
            <div class="item">876427.653.92</div>
          </div>
        </div>
      </div>

			<section class="novaLista margin">
                <a href="mercado.php?acao=mercado_deslogar">
                    <button class="ui primary button direita">Deslogar</button>
                </a>
			</section>
            <?php
            if (isset($_GET['atualizado']) and $_GET['atualizado'] == 'sim'){
                echo '
            <div class="ui horizontal  cor_tercearia">
                Foi
            </div>
            <?php
            ';}elseif(isset($_GET['atualizado']) and $_GET['atualizado'] == 'nao'){
            echo '   
            ?>
             <div class="ui horizontal  cor_tercearia">
                nao Foi
            </div>
            <?php
            ';}
            ?>
			<div class="ui horizontal divider cor_tercearia">
				meus produtos
			</div>

      <a href="produto_cadastro.php"><button class="ui primary button direita">+ Novo produto</button></a>

			<div class="cardMercado margin">
				<div class="ui card">
					<div class="content">
						<div class="header">Nome produto</div>
					</div>
					<div class="content">
						<img class="img_mercado" src="../../imagens/index.jpg">
						
            <div class="ui sub header">
              <span class="right floated">
                R$23,87
              </span>
              <span class= "floated">
                Estoque: 23
              </span>
            </div>

					</div>
          <div class="extra content">
            <button class="ui right floated button">Editar</button>
            <button class="ui left button">Excluir</button>
          </div>
				</div>

			</div>

		</div>
		<div class="one wide column "></div>
	</div>

</body>
<?php
include "footer.php";
}else{
  header('location: mercado_login.php');
}
}else{
  header('location: usuario_login.php');
}